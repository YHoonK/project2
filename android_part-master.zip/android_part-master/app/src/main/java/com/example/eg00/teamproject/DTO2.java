package com.example.eg00.teamproject;

public class DTO2 {
    private String wave_id;
    private String wave_age;
    private String wave_alcohol;

    public String getWave_age() {
        return wave_age;
    }

    public void setWave_age(String wave_age) {
        this.wave_age = wave_age;
    }

    public String getWave_name() {
        return wave_name;
    }

    public void setWave_name(String wave_name) {
        this.wave_name = wave_name;
    }

    private String wave_name;

    public DTO2(String wave_id,String wave_name ,String wave_age, String wave_alcohol) {
        this.wave_id = wave_id;
        this.wave_name = wave_name;
        this.wave_age = wave_age;
        this.wave_alcohol = wave_alcohol;
    }

    public String getWave_id() {
        return wave_id;
    }

    public void setWave_id(String wave_id) {
        this.wave_id = wave_id;
    }


    public String getWave_alcohol() {
        return wave_alcohol;
    }

    public void setWave_alcohol(String wave_alcohol) {
        this.wave_alcohol = wave_alcohol;
    }
}
