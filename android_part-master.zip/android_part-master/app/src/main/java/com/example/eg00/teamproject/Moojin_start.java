package com.example.eg00.teamproject;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.TimePicker;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class Moojin_start extends AppCompatActivity implements  View.OnClickListener{

    int mYear, mMonth, mDay, mHour, mMinute;
    TextView mTxtDate;
    TextView mTxtTime;
    Button btnStart_next , btnStart_before;
    RadioGroup rg;
    TextView start_name, start_index;
    TextView tel , addres;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_moojin_start);




        SharedPreferences kim5 = getSharedPreferences("예약",MODE_PRIVATE);
        String kk = kim5.getString("id","");

        DAO dao = new DAO();



        start_name = findViewById(R.id.editText);
        start_index = findViewById(R.id.editText2);
        tel = findViewById(R.id.editText4);

        mTxtDate = (TextView)findViewById(R.id.txtdate);
        mTxtTime = (TextView)findViewById(R.id.txttime);

        btnStart_before = findViewById(R.id.btnStart_before);
        btnStart_next = findViewById(R.id.btnStrat_next);

        btnStart_next.setOnClickListener(this);
        btnStart_before.setOnClickListener(this);
         rg = findViewById(R.id.radioGroup1);

        //텍스트뷰 2개 연결

        mTxtDate = findViewById(R.id.txtdate);
        mTxtTime = findViewById(R.id.txttime);

        Calendar cal = new GregorianCalendar();
        mYear = cal.get(Calendar.YEAR);
        mMonth = cal.get(Calendar.MONTH);
        mDay = cal.get(Calendar.DAY_OF_MONTH);
        mHour = cal.get(Calendar.HOUR_OF_DAY);
        mMinute = cal.get(Calendar.MINUTE);
        UpdateNow();
        dao.check_Login(kk,start_name,start_index,tel);
    }


    public void mOnClick(View v){

        switch(v.getId()){
            //날짜 대화상자 버튼이 눌리면 대화상자를 보여줌
            case R.id.btnchangedate:
                //여기서 리스너도 등록함
                new DatePickerDialog(Moojin_start.this, mDateSetListener, mYear,
                        mMonth, mDay).show();
                break;
            //시간 대화상자 버튼이 눌리면 대화상자를 보여줌
            case R.id.btnchangetime:
                //여기서 리스너도 등록함
                new TimePickerDialog(Moojin_start.this, mTimeSetListener, mHour,
                        mMinute, false).show();
                break;
        }
    }

    //날짜 대화상자 리스너 부분
    DatePickerDialog.OnDateSetListener mDateSetListener =
            new DatePickerDialog.OnDateSetListener() {



                @Override

                public void onDateSet(DatePicker view, int year, int monthOfYear,

                                      int dayOfMonth) {
                    // TODO Auto-generated method stub
                    //사용자가 입력한 값을 가져온뒤
                    mYear = year;
                    mMonth = monthOfYear;
                    mDay = dayOfMonth;
                    //텍스트뷰의 값을 업데이트함
                    UpdateNow();


                }

            };


    //시간 대화상자 리스너 부분
    TimePickerDialog.OnTimeSetListener mTimeSetListener =
            new TimePickerDialog.OnTimeSetListener() {



                @Override

                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    // TODO Auto-generated method stub
                    mHour = hourOfDay;
                    mMinute = minute;

                    UpdateNow();

                }

            };

    //텍스트뷰의 값을 업데이트 하는 메소드
    void UpdateNow(){
        mTxtDate.setText(String.format("%d/%d/%d", mYear,
                mMonth + 1, mDay));
        mTxtTime.setText(String.format("%d:%d", mHour, mMinute));

    }

    @Override
    public void onClick(View v) {
        int t = v.getId();
        Log.v("hhd", "테스트 " + v.getId());
        if(t == 2131296326){
            RadioButton rd = findViewById(rg.getCheckedRadioButtonId());
            Log.v("hhd", "테스트 " + start_name.getText().toString());
            Log.v("hhd", "테스트 " + start_index.getText().toString());
            Log.v("hhd","테스트 :" +rd.getText().toString());
            if(start_name.getText() != null && start_index.getText() != null && rd.getText() != null) {
                Intent intent = new Intent(getApplicationContext(), Moonjin.class);
                intent.putExtra("검진종목", rd.getText().toString());
                intent.putExtra("이름", start_name.getText().toString());
                intent.putExtra("주민등록번호", start_index.getText().toString());
                intent.putExtra("날짜", mTxtDate.getText());
                intent.putExtra("전화번호", tel.getText());
                startActivity(intent);
                finish();
            }
        }else if(t == 2131296327){
            Intent intent = new Intent(getApplicationContext(),MainActivity.class);
            startActivity(intent);

        }

    }

    }


