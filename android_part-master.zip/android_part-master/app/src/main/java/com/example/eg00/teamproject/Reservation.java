package com.example.eg00.teamproject;

public class Reservation{

       String apply_id,apply_name,apply_age,apply_sex,apply_division,apply_center,apply_pawntel,apply_consulting,apply_dent,apply_drinking;

    public Reservation(String apply_id, String apply_name, String apply_age, String apply_sex, String apply_division, String apply_center, String apply_pawntel, String apply_consulting, String apply_dent, String apply_drinking) {
        this.apply_id = apply_id;
        this.apply_name = apply_name;
        this.apply_age = apply_age;
        this.apply_sex = apply_sex;
        this.apply_division = apply_division;
        this.apply_center = apply_center;
        this.apply_pawntel = apply_pawntel;
        this.apply_consulting = apply_consulting;
        this.apply_dent = apply_dent;
        this.apply_drinking = apply_drinking;
    }

    public String getApply_id() {
        return apply_id;
    }

    public void setApply_id(String apply_id) {
        this.apply_id = apply_id;
    }

    public String getApply_name() {
        return apply_name;
    }

    public void setApply_name(String apply_name) {
        this.apply_name = apply_name;
    }

    public String getApply_age() {
        return apply_age;
    }

    public void setApply_age(String apply_age) {
        this.apply_age = apply_age;
    }

    public String getApply_sex() {
        return apply_sex;
    }

    public void setApply_sex(String apply_sex) {
        this.apply_sex = apply_sex;
    }

    public String getApply_division() {
        return apply_division;
    }

    public void setApply_division(String apply_division) {
        this.apply_division = apply_division;
    }

    public String getApply_center() {
        return apply_center;
    }

    public void setApply_center(String apply_center) {
        this.apply_center = apply_center;
    }

    public String getApply_pawntel() {
        return apply_pawntel;
    }

    public void setApply_pawntel(String apply_pawntel) {
        this.apply_pawntel = apply_pawntel;
    }

    public String getApply_consulting() {
        return apply_consulting;
    }

    public void setApply_consulting(String apply_consulting) {
        this.apply_consulting = apply_consulting;
    }

    public String getApply_dent() {
        return apply_dent;
    }

    public void setApply_dent(String apply_dent) {
        this.apply_dent = apply_dent;
    }

    public String getApply_drinking() {
        return apply_drinking;
    }

    public void setApply_drinking(String apply_drinking) {
        this.apply_drinking = apply_drinking;
    }
}
