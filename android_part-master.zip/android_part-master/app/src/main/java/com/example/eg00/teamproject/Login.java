package com.example.eg00.teamproject;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.se.omapi.Session;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import okhttp3.OkHttpClient;


public class Login extends AppCompatActivity {
    private TextView Login_check;
    private EditText Login_id;
    private EditText Login_pw;
    Timer timer;
    ArrayList<Class> arrayList;
    int tt;
    SharedPreferences login;

    Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            String ms = (String) msg.obj;
            if(ms != null){
                SharedPreferences.Editor editor = login.edit();
                editor.putString("id", Login_id.getText().toString());
                editor.putString("name",ms);
                editor.commit();

                Intent intent = new Intent(getApplicationContext(), arrayList.get(tt));
                startActivity(intent);
                finish();
            }
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Login_id = findViewById(R.id.Login_id);
        Login_pw = findViewById(R.id.Login_pw);
        Login_check = findViewById(R.id.Login_check);
        timer = new Timer();

        login = getSharedPreferences("예약", MODE_PRIVATE);
        arrayList = new ArrayList();
        tt = Integer.parseInt(getIntent().getStringExtra("체크"));
        Log.v("ddaa", "ddaa" + tt);



        arrayList.add(MainActivity.class);
        arrayList.add(Moojin_start.class);
        arrayList.add(Reservation_confirm.class); // 진료시작;
        arrayList.add(Becone.class);
        SharedPreferences kim5 = getSharedPreferences("예약", MODE_PRIVATE);
        String kk = kim5.getString("id", "");
        Log.v("ddaa",kk);

        if(kk.equals("admin1") || kk.equals("admin2") || kk.equals("admin3")){
            Intent intent = new Intent(getApplicationContext(), Manager.class);
            startActivity(intent);
        }else if (!kk.equals("")) {
            Intent intent = new Intent(getApplicationContext(), arrayList.get(tt));
            startActivity(intent);
        }
        Log.v("김영훈 ", "도주중" + kk);

        findViewById(R.id.btn_Login).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Login_check.setText("");
                String a = Login_id.getText().toString();
                String b = Login_pw.getText().toString();

                Log.v("hhd", "테스트" + Login_check.getText().toString());
                if (a.equals("admin1") && b.equals("admin1")) {
                    Intent intent = new Intent(getApplicationContext(), Manager.class);
                    SharedPreferences.Editor editor = login.edit();
                    editor.putString("id", a);
                    editor.commit();
                    startActivity(intent);
                    finish();
                }else if(a.equals("admin2") && b.equals("admin2")){
                    Intent intent = new Intent(getApplicationContext(), Manager.class);
                    SharedPreferences.Editor editor = login.edit();
                    editor.putString("id",a);
                    editor.commit();
                    startActivity(intent);
                    finish();
                }else if(a.equals("admin3") && b.equals("admin3")){
                    Intent intent = new Intent(getApplicationContext(), Manager.class);
                    SharedPreferences.Editor editor = login.edit();
                    editor.putString("id", a);
                    editor.commit();
                    startActivity(intent);
                    finish();
                }else {
                    DAO dao = new DAO();
                    dao.Login(Login_check, a, b,handler);
                }




            }
        });


        findViewById(R.id.btn_update).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(), Update.class);
                startActivity(intent);
            }
        });


   }
}






