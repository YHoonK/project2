package com.example.eg00.teamproject;

public class DTO {
    private String dent_id;
    private String dent_name;
    private String dent_age;
    private String dent_year;

    public String getDent_name() {
        return dent_name;
    }

    public void setDent_name(String dent_name) {
        this.dent_name = dent_name;
    }

    public DTO(String dent_id, String dent_name, String dent_age, String dent_year) {

        this.dent_id = dent_id;
        this.dent_name = dent_name;

        this.dent_age = dent_age;
        this.dent_year = dent_year;

    }

    public String getDent_id() {
        return dent_id;
    }

    public void setDent_id(String dent_id) {
        this.dent_id = dent_id;
    }

    public String getDent_age() {
        return dent_age;
    }

    public void setDent_age(String dent_age) {
        this.dent_age = dent_age;
    }

    public String getDent_year() {
        return dent_year;
    }

    public void setDent_year(String dent_year)
    {
        this.dent_year = dent_year;
    }
}
