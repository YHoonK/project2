package com.example.eg00.teamproject;

public class User {
    public int id;
    public String user_id;
    public String user_pwd;
    public String user_name;
    public String user_age;
    public String user_sex;
    public String user_tel;
    public String user_pawntel;
    public String user_email;
    public String user_date;
    public String user_usernum;

    public User(int id, String user_id, String user_pwd, String user_name, String user_age, String user_sex, String user_tel, String user_pawntel, String user_email, String user_date, String user_usernum, String user_add) {
        this.id = id;
        this.user_id = user_id;
        this.user_pwd = user_pwd;
        this.user_name = user_name;
        this.user_age = user_age;
        this.user_sex = user_sex;
        this.user_tel = user_tel;
        this.user_pawntel = user_pawntel;
        this.user_email = user_email;
        this.user_date = user_date;
        this.user_usernum = user_usernum;
        this.user_add = user_add;
    }

    public User() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getUser_pwd() {
        return user_pwd;
    }

    public void setUser_pwd(String user_pwd) {
        this.user_pwd = user_pwd;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getUser_age() {
        return user_age;
    }

    public void setUser_age(String user_age) {
        this.user_age = user_age;
    }

    public String getUser_sex() {
        return user_sex;
    }

    public void setUser_sex(String user_sex) {
        this.user_sex = user_sex;
    }

    public String getUser_tel() {
        return user_tel;
    }

    public void setUser_tel(String user_tel) {
        this.user_tel = user_tel;
    }

    public String getUser_pawntel() {
        return user_pawntel;
    }

    public void setUser_pawntel(String user_pawntel) {
        this.user_pawntel = user_pawntel;
    }

    public String getUser_email() {
        return user_email;
    }

    public void setUser_email(String user_email) {
        this.user_email = user_email;
    }

    public String getUser_date() {
        return user_date;
    }

    public void setUser_date(String user_date) {
        this.user_date = user_date;
    }

    public String getUser_usernum() {
        return user_usernum;
    }

    public void setUser_usernum(String user_usernum) {
        this.user_usernum = user_usernum;
    }

    public String getUser_add() {
        return user_add;
    }

    public void setUser_add(String user_add) {
        this.user_add = user_add;
    }

    public String user_add;




}
