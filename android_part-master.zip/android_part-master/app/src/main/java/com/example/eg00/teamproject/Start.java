package com.example.eg00.teamproject;

public class Start {
    int num_data;
    String time_data;
    String dp_data;

    public Start(int num_data, String time_data, String dp_data) {
        this.num_data = num_data;
        this.time_data = time_data;
        this.dp_data = dp_data;
    }

    public int num_data() {

        return num_data;
    }

    public void num_data(int num_data) {
        this.num_data = num_data;
    }

    public String getTime_data() {
        return time_data;
    }

    public void setTime_data(String time_data) {
        this.time_data = time_data;
    }

    public String getDp_data() {
        return dp_data;
    }

    public void setDp_data(String dp_data) {
        this.dp_data = dp_data;
    }
}
