package com.example.eg00.teamproject;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;


public class Moonjin extends AppCompatActivity implements View.OnClickListener {
    MainFragment02 fragment01;
    MainFragment03 fragment02;
    MainFragment04 fragment03;
    MainFragment05 fragment04;
    Fragment fragment05;
    ScrollView sc;
    int a = 0;
    ArrayList arrayList;
    int mYear, mMonth, mDay, mHour, mMinute;
    TextView mTxtDate;
    TextView mTxtTime;
    String r_select, r_day, r_name, r_rrn,r_tel;
    String age;
    String sex;
    String m1;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.moojin);
        arrayList = new ArrayList();
        fragment01 = new MainFragment02();
        fragment02 = new MainFragment03();
        fragment03 = new MainFragment04();
        fragment04 = new MainFragment05();

        arrayList.add(fragment01);
        arrayList.add(fragment02);
        arrayList.add(fragment03);
        arrayList.add(fragment04);
        arrayList.add(fragment05);

        getSupportFragmentManager().beginTransaction().replace(R.id.container, (Fragment) arrayList.get(a)).commit();

        r_select = getIntent().getStringExtra("검진종목");
        Log.v("hhd", "aaadd~ : " + r_select);
        r_name = getIntent().getStringExtra("이름");
        Log.v("hhd", "aaadddd : " + r_name);
        r_rrn = getIntent().getStringExtra("주민등록번호");
        Log.v("hhd", "ffffffff : " + r_rrn);
        r_day = getIntent().getStringExtra("날짜");
        Log.v("hhd", "zzzzzzzzz : " + r_day);
        r_tel = getIntent().getStringExtra("전화번호");

        String rrn[] = r_rrn.split("-");
        String tt1 = rrn[0];
        String tt2 = rrn[1];
        int c = Integer.parseInt(tt2.substring(0,1));


        int a = Integer.parseInt(tt1.substring(0,2));
         age = ""+(((a-100)*-1)+19);
         sex = ""+c;


        findViewById(R.id.btnNext1).setOnClickListener(this);
        findViewById(R.id.btnBefore1).setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        int c = v.getId();
        Log.v("hhd", "ab" + a);
        Log.v("hhd", "ab" + v.getId());
        RadioGroup radioGroup = findViewById(R.id.send1);
        final RadioGroup radioGroup1 = findViewById(R.id.radioGroup1);
        if (a == 3) {
            a--;
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("문진표 ");
            builder.setMessage("마지막 페이지입니다 \n 문진이 끝나셨습니까?");
            builder.setPositiveButton("예",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            Toast.makeText(getApplicationContext(), "예약이 완료되었습니다.", Toast.LENGTH_LONG).show();
                             RadioButton radioButton = findViewById(radioGroup1.getCheckedRadioButtonId());
                             String dent = "0";
                             if(radioButton.getText().toString().equals("예")){
                                dent ="1" ;
                            }
                           Reservation reservation = new Reservation("1","yong709",age,sex,"1",r_name,
                                   "010-7475-8911",r_day,dent,m1);
                           DAO dao = new DAO();
                           dao.join(reservation);
                            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                            startActivity(intent);
                            finish();
                        }
                    });
            builder.setNegativeButton("아니오",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });
            builder.show();
        } else if (c == 2131296324) {
            a++;
            if(a==2){
                RadioButton rg = findViewById(radioGroup.getCheckedRadioButtonId());
                m1 = rg.getText().toString();
                if(m1.equals("안마신다")){
                    m1 ="0";
                }else{
                    m1 = "1";
                }
                Log.v("hhd","abba!!!1"+m1);
            }
            getSupportFragmentManager().beginTransaction().replace(R.id.container, (Fragment) arrayList.get(a)).commit();

            Log.v("hhd", "qqqqq" + a);
        } else if (c == 2131296323) {
            if (a == 0 || a == -1) {
                Log.v("hhd", "agag" + a);
                Intent intent = new Intent(getApplicationContext(), Moojin_start.class);
                startActivity(intent);
            } else {
                a--;
                Log.v("hhd", "gaga" + a);
                getSupportFragmentManager().beginTransaction().replace(R.id.container, (Fragment) arrayList.get(a)).commit();

            }

        }



    }
}