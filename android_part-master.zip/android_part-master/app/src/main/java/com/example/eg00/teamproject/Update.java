package com.example.eg00.teamproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class Update extends AppCompatActivity {
    TextView e_Id, e_Pw, e_Email, e_Phone, e_Num, e_Name, e_Repw ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        e_Id = findViewById(R.id.e_Id);
        e_Pw = findViewById(R.id.e_Pw);
        e_Email = findViewById(R.id.e_Email);
        e_Phone = findViewById(R.id.e_Phone);
        e_Num = findViewById(R.id.e_Num);
        e_Name = findViewById(R.id.e_Name);
        e_Repw = findViewById(R.id.e_Repw);


        findViewById(R.id.btn_Re).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(e_Id.getText().toString() !=null){
                    Log.v("hhd","aaag ");
                    DAO dao = new DAO();
                    dao.select(e_Name.getText().toString());
                    Log.v("hhd","aaag ");
                }

            }
        });


        findViewById(R.id.btnUpdate).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DAO dao = new DAO();
                User user = new User(1,e_Id.getText().toString(), e_Pw.getText().toString(),e_Name.getText().toString(),
                                        "1","20","1",e_Phone    .getText().toString(), e_Email.getText().toString(),"1",
                        e_Num.getText().toString(), "1");
                dao.Login1(user);
                Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

    }
}
