package com.example.eg00.teamproject;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;


public class Reservation_confirm extends AppCompatActivity {
    TextView txID, txName, txPhone, txDate;
    ArrayList arrayList,arrayList2;
    String Name , id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reservation_confirm);
        SharedPreferences sh = getSharedPreferences("예약", MODE_PRIVATE);
        id = sh.getString("id", "");
        Name = sh.getString("name", "");
        Log.v("name","체크용"+Name);
        Log.v("name","체크용"+id);

        txID = findViewById(R.id.txID);
        txName = findViewById(R.id.txName);
        txPhone = findViewById(R.id.txPhone);
        txDate = findViewById(R.id.txDate);

        DAO dao = new DAO();
        arrayList = new ArrayList();
        dao.data1(arrayList, Name, handler);
        arrayList2 = new ArrayList();
        DTO dto = new DTO("1","hhd","35","2018");
    }
    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            Log.v("hhh","체크영");
            String m = (String) msg.obj;
            Log.v("hhh","체크영"+m);
            if (m != null) {
                Log.v("hhh", "hhhd" + arrayList.size());
                txID.setText(id);
                txName.setText(Name);
                for (int i = 0; i < arrayList.size(); i++) {
                    txDate.setText(arrayList.get(1).toString());
                    txPhone.setText(arrayList.get(0).toString());
                }
            }
        }
    };

};