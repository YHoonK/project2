package com.example.eg00.teamproject;

public class time {
    private String num;
    private String wait_time;

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getWait_time() {
        return wait_time;
    }

    public void setWait_time(String wait_time) {
        this.wait_time = wait_time;
    }

    public time(String num, String wait_time) {

        this.num = num;
        this.wait_time = wait_time;
    }
}
