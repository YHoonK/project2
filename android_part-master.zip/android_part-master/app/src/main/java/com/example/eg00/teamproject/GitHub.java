package com.example.eg00.teamproject;

import android.util.Log;

import java.util.List;

import okhttp3.ResponseBody;
import okhttp3.internal.Version;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Path;
import retrofit2.http.Query;
import retrofit2.http.Url;

public interface GitHub {
    @GET("api/team/userset/")
    Call<List<User>> post_version(@Query("format") String fomat);
/*    @Multipart*/


    @POST("api/team/userset/?format=json")
    Call<ResponseBody> post_version1(@Body User user);


    //예약 테이블 관련
    @POST("api/team/apply/?format=json")
    Call<ResponseBody> post_reservation(@Body Reservation user);

    @GET("api/team/apply/")
    Call<List<Reservation>> post_outPUT(@Query("format") String fomat);


    //치과 테이블 관련
    @POST("api/team/dent/?format=json")
    Call<ResponseBody> post_dent(@Body DTO user);

    @GET("api/team/dent_dp/")
    Call<List<DTO>> post_outPUT2(@Query("format") String fomat);


    //초음파 테이블 관련
    @POST("api/team/wave/?format=json")
    Call<DTO2> post_dent(@Body DTO2 user);

    @GET("api/team/wave_dp/")
    Call<List<DTO2>> post_outPUT3(@Query("format") String fomat);



    //기초 검사실 테이블 관련
    @POST("api/team/basic/?format=json")
    Call<DTO3> post_basic(@Body DTO3 user);

    @GET("api/team/basic_dp/")
    Call<List<DTO3>> post_outPUT4(@Query("format") String fomat);
    //여기가 딜리트 문이야
    //저주소 톡방에는 삭제할때 보내달라는 주소 였어 한번 확인해봐


    //waves
    @GET("api/dpdata/{abc}")
    Call<ResponseBody>post_delete(@Path("abc") String b);


    @GET("api/team/basic_dp/")
    Call<List<DTO3>> basic(@Query("format") String fomat);

    @GET("api/team/dent_dp/")
    Call<List<DTO>> dent(@Query("format") String fomat);

    @GET("api/team/wave_dp/")
    Call<List<DTO2>> wave(@Query("format") String fomat);



    @GET("api/setdata/{abc}")
    Call<List<Start>> post_start(@Path("abc") String fomat);

    @GET("api/nowdata/{abc}")
    Call<List<time>> post_check(@Path("abc") String fomat);

}
