package com.example.eg00.teamproject;

import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class Manager extends AppCompatActivity implements ListViewBtnAdapter.ListBtnClickListener {

    ListView listview;
    ListViewBtnAdapter adapter;
    ArrayList<DTO> arrayList;
    ArrayList<DTO2> arrayList1;
    ArrayList<DTO3> arrayList2;
    ArrayList arrayList5;
    int kim = 0;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manager);
        SharedPreferences sh = getSharedPreferences("예약", MODE_PRIVATE);
        String user_id = sh.getString("id", "");
        arrayList5 = new ArrayList();
        arrayList5.add("");


        arrayList = new ArrayList();
        arrayList1 = new ArrayList();
        arrayList2 = new ArrayList();


        DAO dao = new DAO();
        if (user_id.equals("admin1")) {
            Log.v("hhz", "hhd");
            kim = 1;
            //admin1 이란 값이 들어오면 이게 실행될꺼고
            dao.outputManager(arrayList, handler);
            //이게 실행되면
        } else if (user_id.equals("admin2")) {
            kim = 2;
            dao.outputManager2(arrayList1, handler);
        } else if (user_id.equals("admin3")) {
            kim = 3;
            dao.outputManager3(arrayList2, handler);
        }
        /*  지금 보면 내가 넘긴 값은  kim이라는 값이야*/
        // 이쪽에 arrlist5라는리스트를 넘겨주면서
        adapter = new ListViewBtnAdapter(getApplicationContext(), R.layout.listview_btn_item, arrayList5, this, kim);
        handler.sendEmptyMessage(0);


    }

    Handler handler1 = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            handler1.sendEmptyMessageDelayed(0, 1000);
            //이꺼슬려는꺼찌>ㅇ근데 핸드러는 호출용으로 박에안됨?
            //ㄴㄴ 호출용이라끼뽀따는
            //CREATE 예써는 한뻔 씰헁하꼬 긑나짢아

        }
    };


    @Override
    public void onListBtnClick(int position) {
        Toast.makeText(this, Integer.toString(position + 1) + " Item is selected..", Toast.LENGTH_SHORT).show();
    }
/*
    public boolean loadItemsFromDB(ArrayList list) {
        DTO item;


        // 순서를 위한 i 값을 1로 초기화.
        return true;
    }
*/


    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {

            String m = (String) msg.obj;
            if (m == "1") {
                for (int i = 0; i < arrayList.size(); i++) {
                    //1번과의 예약 데이터가 들어올꺼고 그거를 array 리스트에 저장시킨거야
                    if (i == 0) {
                        arrayList5.set(0, arrayList.get(i).getDent_name());
                    } else {
                        arrayList5.add((arrayList.get(i).getDent_name()));
                    }
                }
            } else if (m == "2") {
                for (int i = 0; i < arrayList1.size(); i++) {
                    if (i == 0) {
                        arrayList5.set(0, arrayList1.get(i).getWave_name());
                    } else {
                        arrayList5.add((arrayList1.get(i).getWave_name()));
                    }
                }
            } else if (m == "3") {
                for (int i = 0; i < arrayList2.size(); i++) {
                    if (i == 0) {
                        arrayList5.set(0, arrayList2.get(i).getBasic_name());
                    } else {
                        arrayList5.add((arrayList2.get(i).getBasic_name()));
                    }
                    }
            }

            // 리스트뷰 참조 및 Adapter달기

            listview = findViewById(R.id.listView);
            listview.setAdapter(adapter);
            adapter.notifyDataSetChanged();
            handler.sendEmptyMessageDelayed(0, 1000);
        }


    };
}






