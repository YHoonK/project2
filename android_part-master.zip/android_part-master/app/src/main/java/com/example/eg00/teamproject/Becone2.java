package com.example.eg00.teamproject;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.RemoteException;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.altbeacon.beacon.Beacon;
import org.altbeacon.beacon.BeaconConsumer;
import org.altbeacon.beacon.BeaconManager;
import org.altbeacon.beacon.BeaconParser;
import org.altbeacon.beacon.RangeNotifier;
import org.altbeacon.beacon.Region;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

public class Becone2 extends AppCompatActivity implements BeaconConsumer {
    private BeaconManager beaconManager;
    private List<Beacon> beaconList = new ArrayList<>();
    TextView textView;
    int a[] = new int[4];
    double b[] = new double[4];
    double c = 0.0;
    double a11, a22, a33, a44;
    TextView lat, long1, e_dp;
    EditText e_person, e_time;
    ArrayList arrayList;
    String Id, name;
    DAO dao;
    int aaa = 0;
    int aaa1 = 0;
    int aaa2 = 0;
    int bb = 0;
    int ttt = 0;
    int ttt1 = 0;
    int ttt2 = 0;
    AlertDialog dialog;
    AlertDialog.Builder dialog1;
    ArrayList arry;
    int t = 0;
    int aa1, aa2, aa3;
    ImageView imageView;
    ArrayList arrayli;
    int end = 0;
    ImageView image;
    int stop = 0;

    HashMap<String,String> map = new HashMap<>();
    HashMap<String,Integer> imgOne = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_becone);
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
        lat = findViewById(R.id.textView);
        long1 = findViewById(R.id.textView9);
        e_person = findViewById(R.id.e_per);
        e_time = findViewById(R.id.e_time);
        e_dp = findViewById(R.id.e_dp);
        imageView = findViewById(R.id.imageView);
        arrayList = new ArrayList();
        arrayli = new ArrayList();
         image = findViewById(R.id.dialog_imageview);
        image.setVisibility(View.GONE);


        SharedPreferences a = getSharedPreferences("예약", MODE_PRIVATE);
        Id = a.getString("id", "");
        name = a.getString("name", "");
        Log.v("name", "확인중입니다." + name);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        start();
        dialog1 = new AlertDialog.Builder(this);
        dialog1.setTitle("진료 페이지 ");
        dialog1.setMessage("진료를 시작하시겠습니까??");
        dialog1.setPositiveButton("예",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        bb = 1;
                        Log.v("hhd", "" + b);
                        handler1.sendEmptyMessage(0);
                    }
                });
        dialog1.setNegativeButton("아니오",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(intent);
                        finish();
                    }
                });
        dialog1.show();
        handler.sendEmptyMessage(0);


        //---------------------------------------
        setting();
    }


    private void start() {
        beaconManager = BeaconManager.getInstanceForApplication(this);
        beaconManager.getBeaconParsers().add(new BeaconParser().setBeaconLayout("m:2-3=0215,i:4-19,i:20-21,i:22-23,p:24-24"));
        beaconManager.bind(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        beaconManager.unbind(this);
    }

    @Override
    public void onBeaconServiceConnect() {
        beaconManager.setRangeNotifier(new RangeNotifier() {
            @Override
            public void didRangeBeaconsInRegion(Collection<Beacon> beacons, Region region) {
                if (beacons.size() > 0) {
                    beaconList.clear();
                    Log.v("hhd", "확인중");
                    for (Beacon beacon : beacons) {
                        Log.v("비콘 : ", "비콘 아이디1" + beacon.getId3() + "비콘 아이디2" + beacon.getId2() + "신호" + beacon.getId3() + "거리 : " + beacon.getDistance() + "   신호  : " + beacon.getRssi());
                        beaconList.add(beacon);
                    }
                }
            }
        });
        try {
            beaconManager.startRangingBeaconsInRegion(new Region("myRangingUniqueId", null, null, null));
        } catch (RemoteException e) {
        }
    }



    Handler handler = new Handler() {
        public void handleMessage(Message msg) {
            Log.v("hhd", "체크중");
            if (beaconList.size() > 2) {
                for (int i = 0; i < beaconList.size(); i++) {
                    String ddd = String.valueOf(beaconList.get(i).getId3());
                    Log.v("hhd", "// " + ddd);
                    if (ddd.equals("1")) {
                        a33 = beaconList.get(i).getDistance(); // dent_dp
                    } else if (ddd.equals("2")) {
                        a22 = beaconList.get(i).getDistance(); // wave_dp
                    } else if (ddd.equals("3")) {
                        a11 = beaconList.get(i).getDistance();
                    } else if (ddd.equals("4")) {
                        a44 = beaconList.get(i).getDistance(); // basic_dp
                    }
                }
                TextView textView23 = findViewById(R.id.e_dp);
//                textView23.setText("2번 비콘 : " + a22 + "//  3번비콘 : " + a33 + " ///  4번비콘 :  " + a44);
                Location t = getLocationWithTrilateration(a22, a33, a44);
                double lat = t.getLatitude();
                double loong = t.getLongitude();
                TextView textView123 = findViewById(R.id.textView9);
                textView123.setText("거리 1 : " + lat + "\n" + "거리2 :" + loong);
                TextView tao = findViewById(R.id.tv110);

                if (a33 < 2) {
                    aaa = 1;
                } else if (a44 < 2) {
                    aaa1 = 1;
                } else if (a22 < 2) {
                    aaa2 = 1;
                }


                if (textView23.getText().equals("기초검사실")) {
                    tao.setText("xx" + aaa);
                    if (aaa == 1) {
                        if (a33 > 2.5) {
                            if (lat > 0.9) {
                                ttt++;
                                if (ttt == 3) {
                                    showMessge();
                                    ttt = 0;
                                    aaa = 0;
                                }
                            }
                        }
                    }
                } else if (textView23.getText().equals("치과")) {
                    tao.setText("xx" + aaa1);

                    if (aaa1 == 1) {
                        if (a44 > 2.5) {
                            if (loong > -1) {
                                ttt1++;
                                if (ttt1 == 3) {
                                    showMessge();
                                    ttt1 = 0;
                                    aaa1 = 0;
                                }
                            }
                        }
                    }
                } else if (textView23.getText().equals("초음파실")) {
                    tao.setText("xx" + aaa2);
                    if (aaa2 == 1) {
                        if (a22 > 2) {
                            if (loong > -0.5) {
                                ttt2++;
                                if (ttt2 == 3) {
                                    showMessge();
                                    ttt2 = 0;
                                    aaa2 = 0;
                                }

                            }
                        }
                    }
                }
            }
            handler.sendEmptyMessageDelayed(0, 1000);
        }
    };


    //이걸 활용하자
    public static Location getLocationWithTrilateration(double distanceA, double distanceB, double distanceC) {
        double bAlat = 3.5;
        double bAlong = -3.0;
        double bBlat = -3.5;
        double bBlong = 3.0;
        double bClat = -3.2;
        double bClong = -3.0;
        double W, Z, foundBeaconLat, foundBeaconLong, foundBeaconLongFilter;
        W = distanceA * distanceA - distanceB * distanceB - bAlat * bAlat - bAlong * bAlong + bBlat * bBlat + bBlong * bBlong;
        Z = distanceB * distanceB - distanceC * distanceC - bBlat * bBlat - bBlong * bBlong + bClat * bClat + bClong * bClong;
        foundBeaconLat = (W * (bClong - bBlong) - Z * (bBlong - bAlong)) / (2 * ((bBlat - bAlat) * (bClong - bBlong) - (bClat - bBlat) * (bBlong - bAlong)));
        foundBeaconLong = (W - 2 * foundBeaconLat * (bBlat - bAlat)) / (2 * (bBlong - bAlong));
        //`foundBeaconLongFilter` is a second measure of `foundBeaconLong` to mitigate errors
        foundBeaconLongFilter = (Z - 2 * foundBeaconLat * (bClat - bBlat)) / (2 * (bClong - bBlong));
        foundBeaconLong = (foundBeaconLong + foundBeaconLongFilter) / 2;
        Location foundLocation = new Location("Location");
        foundLocation.setLatitude(foundBeaconLat);
        foundLocation.setLongitude(foundBeaconLong);
        return foundLocation;
    }


    Handler handler1 = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if (bb == 1) {
                DAO dao = new DAO();
                dao.start(Id, checkHandler1);
                bb = 0;
            }
            if (bb == 0) {
                Log.v("확인중", "확인중입니다." + name);
                String yong = e_dp.getText().toString();
                DAO dao = new DAO();
                if (yong.equals("기초검사실")) {
                    Log.v("체크용", "체크용");
                    dao.basic(name, checkHandler);
                } else if (yong.equals("치과")) {
                    dao.dent(name, checkHandler);
                } else if (yong.equals("초음파실")) {
                    dao.wave(name, checkHandler);
                }
            }


            handler1.sendEmptyMessageDelayed(0, 5000);
        }

    };


    public void NextMessge() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("진료");
        builder.setMessage("다음 진료를 시작하시겠습니까?");
        builder.setIcon(android.R.drawable.ic_dialog_alert);
        builder.setPositiveButton("예", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder.setNegativeButton("아니오", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }


    public void showMessge() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("진료");
        builder.setMessage("진료를 종료하시겠습니까??");
        builder.setIcon(android.R.drawable.ic_dialog_alert);
        builder.setPositiveButton("예", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
        builder.setNegativeButton("아니오", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getApplicationContext(), "진료실로 돌아가주시길 바랍니다.", Toast.LENGTH_LONG).show();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    Handler checkHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            String a = (String) msg.obj;
            Log.v("확인중", "확인중 :  " + a);
            DAO dao = new DAO();
            if (a.equals("0")) {
                stop++;
                Log.v("123","확인중 : "+stop);
                if(stop <3) {
                    dao.start(Id, checkHandler1);
                }
            } else {
                e_person.setText(a);
            }
        }
    };


    private void setting(){
        map.put("기초검사실","기초검사실");
        map.put("치과","치과");
        map.put("초음파실","초음파실");
        imgOne.put("기초검사실",R.drawable.stasic);
        imgOne.put("치과",R.drawable.stwave);
        imgOne.put("초음파실",R.drawable.stdent);
    }

    Handler checkHandler1 = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            arry = (ArrayList) msg.obj;
            if (arry.size() != 0) {
                if (t == 0) {
                    e_dp.setText(arry.get(2).toString());
                    e_person.setText(arry.get(0).toString());
                    e_time.setText(arry.get(1).toString());

                    String k = (String)e_dp.getText();
                    map.remove(k);
                    Log.v("hhd",map.size()+"");
                    imageView.setImageResource(imgOne.get(k));
                }
                if (t == 1) {
                    NextMessge();
                    t++;
                    Log.v("OK",":"+t);
                }
                if (t == 2) {
                    e_dp.setText(arry.get(2).toString());
                    e_person.setText(arry.get(0).toString());
                    e_time.setText(arry.get(1).toString());
                    Log.v("OK","::"+t);
                    Log.v("OK","::"+aa1);
                    t = 0;

                    if (aa1 == 1) {
                        if (e_dp.getText().equals("치과")) {
                            imageView.setImageResource(R.drawable.basicwave);
                            aa1 = 2;
                        } else if (e_dp.getText().equals("초음파실")) {
                            imageView.setImageResource(R.drawable.basicdent);
                            aa1 = 3;
                        }

                    } else if (aa2 == 1) {
                        if (e_dp.getText().equals("초음파실")) {
                            imageView.setImageResource(R.drawable.dentwave);
                            aa2 = 2;
                        } else if (e_dp.getText().equals("기초검사실")) {
                            imageView.setImageResource(R.drawable.dentbasic); // 영훈이가 주면 옮기기
                            aa2 = 3;
                        }
                        aa2 = 2;
                    } else if (aa3 == 1) {
                        if (e_dp.getText().equals("치과")) {
                            imageView.setImageResource(R.drawable.wavedent);
                            aa3 = 2;
                        } else if (e_dp.getText().equals("기초검사실")) {
                            imageView.setImageResource(R.drawable.wavebasic);
                            aa2 = 3;
                        }

                    }else if (aa1 == 2) {
                        imageView.setImageResource(R.drawable.wavedent);
                        end =1;
                    } else if (aa1 == 3) {
                        imageView.setImageResource(R.drawable.dentwave);
                        end =1;
                    } else if (aa2 == 2) {
                        imageView.setImageResource(R.drawable.wavebasic);
                        end =1;
                    } else if (aa2 == 3) {
                        imageView.setImageResource(R.drawable.basicwave);
                        end =1;
                    } else if (aa3 == 2) {
                        imageView.setImageResource(R.drawable.dentbasic);
                        end =1;
                    } else if (aa3 == 3) {
                        imageView.setImageResource(R.drawable.basicdent);
                        end =1;
                    }
                }
            }
            if(end ==1){
                image.setVisibility(View.VISIBLE);
                finisht.sendEmptyMessageDelayed(0,3000);
            }
            t++;
        }
    };


    Handler finisht = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            Intent intent = new Intent(getApplicationContext(),MainActivity.class);
            startActivity(intent);
            finish();
        }
    };


}




//안쓰는것
//칼만필터 사용할지....말지.....
/*
class KalmanFilter {
    private double Q = 0.00001;
    private double R = 0.001;
    private double X = 0, P = 1, K;

    // 생성자에는 초기값을 넣어주어야 한다. 이전에 수치가 없으면 아무 의미가 없으므로
    KalmanFilter(double initValue) {
        X = initValue;
    }

    // 현재값을 받아 계산된 공식을 적용하고 반환한다
    public double update(double measurement) {
        measurementUpdate();
        X = X + (measurement - X) * K;
        return X;
    }

    // 이전의 값들을 공식을 이용하여 계산한다.
    private void measurementUpdate() {
        K = (P + Q) / (P + Q + R);
        P = R * (P + Q) / (R + P + Q);
    }
}*/
