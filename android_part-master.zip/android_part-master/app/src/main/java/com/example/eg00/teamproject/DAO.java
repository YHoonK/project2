package com.example.eg00.teamproject;

import android.app.Application;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

//http://interconnection.tistory.com/73
public class DAO extends Application {
    public boolean c = false;
    Retrofit retrofit;
    private final String BASE_URL = "http://172.30.1.5:8000/";
    GitHub gitHub;

    public void init() {
        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create()).client(createOkHttpClient())
                .build();

    }

    public void Login(final TextView textView, final String id, final String pw1, final Handler handler) {
        init();
        GitHub gitHub = retrofit.create(GitHub.class);
        Call<List<User>> call = gitHub.post_version("json");
        call.enqueue(new Callback<List<User>>() {
            @Override
            public void onResponse(Call<List<User>> call, Response<List<User>> response) {
                List<User> user1 = response.body();
                Log.v("hhd", "dhh");
                String m = null;
                for (User user : user1) {
                    if (id.equals(user.user_id)) {
                        Log.v("hhd", "check");
                        if (pw1.equals(user.user_pwd)) {
                            Log.v("hhd", "dhhh");
                            m = user.user_name;
                        }
                    }
                }
                if (handler != null) {
                    Message message = handler.obtainMessage();
                    message.obj = m;
                    handler.sendMessage(message);
                }

            }

            @Override
            public void onFailure(Call<List<User>> call, Throwable t) {

            }
        });
    }


    private static OkHttpClient createOkHttpClient() {
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        builder.addInterceptor(interceptor);
        return builder.build();
    }

    public void Login1(User user) {
        init();
        GitHub gitHub = retrofit.create(GitHub.class);
        Call<ResponseBody> call = gitHub.post_version1(user);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    Log.v("hhdd", "");
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {

            }
        });
    }

    public void select(final String s) {
        init();
        GitHub gitHub = retrofit.create(GitHub.class);
        Call<List<User>> call = gitHub.post_version("json");
        call.enqueue(new Callback<List<User>>() {
            @Override
            public void onResponse(Call<List<User>> call, Response<List<User>> response) {
                List<User> user = response.body();
                for (User user1 : user) {
                    if (user1.user_name.equals(s)) {
                        Log.v("hhd", "ddhh ");
                        Toast.makeText(getApplicationContext(), "중복값이 존재합니다.", Toast.LENGTH_LONG).show();
                        Log.v("hhd", "ddhhh ");
                    }
                }
            }

            @Override
            public void onFailure(Call<List<User>> call, Throwable t) {

            }
        });
    }


    public void check_Login(final String kk, final TextView start_name, final TextView start_index, final TextView tel) {
        init();
        GitHub gitHub = retrofit.create(GitHub.class);
        Call<List<User>> call = gitHub.post_version("json");
        call.enqueue(new Callback<List<User>>() {
            @Override
            public void onResponse(Call<List<User>> call, Response<List<User>> response) {
                List<User> user1 = response.body();
                Log.v("hhd", "00000000p");
                for (User user : user1) {
                    if (kk.equals(user.user_id)) {
                        Log.v("hhd", "00000000p");
                        start_name.setText(user.user_name);
                        start_index.setText(user.user_usernum);
                        tel.setText(user.user_pawntel);
                    }
                }
            }

            @Override
            public void onFailure(Call<List<User>> call, Throwable t) {

            }
        });
    }

    public void join(Reservation reservation) {
        init();
        GitHub gitHub = retrofit.create(GitHub.class);
        Call<ResponseBody> call = gitHub.post_reservation(reservation);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    Log.v("hhd", "dddh");
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {

            }
        });
    }

    public void output(final TextView txId, final TextView txName, final TextView txDate, final TextView txPhone) {
        init();
        GitHub gitHub = retrofit.create(GitHub.class);
        Call<List<Reservation>> call = gitHub.post_outPUT("api");
        call.enqueue(new Callback<List<Reservation>>() {
            @Override
            public void onResponse(Call<List<Reservation>> call, Response<List<Reservation>> response) {
                List<Reservation> user1 = response.body();
                for (Reservation user : user1) {
                    if (txName.equals(user.apply_name)) {
                        Log.v("hhd", "00000000p");
                        txId.setText("" + user.apply_id);
                        txDate.setText(user.apply_consulting);
                        txPhone.setText(user.apply_pawntel);
                    }
                }
            }

            @Override
            public void onFailure(Call<List<Reservation>> call, Throwable t) {

            }
        });
    }

    public void data1(final ArrayList arrayList, final String Name, final Handler handler) {
        init();
        GitHub gitHub = retrofit.create(GitHub.class);
        Call<List<Reservation>> call = gitHub.post_outPUT("json");
        call.enqueue(new Callback<List<Reservation>>() {
            @Override
            public void onResponse(Call<List<Reservation>> call, Response<List<Reservation>> response) {
                List<Reservation> user1 = response.body();
                String m = null;
                for (Reservation user : user1) {
                    if (Name.equals(user.apply_center)) {
                        Log.v("hhd", "!!!dd" + user.apply_pawntel + "/" + user.apply_consulting);
                        arrayList.add(user.apply_pawntel);
                        arrayList.add(user.apply_consulting);
                        m = "1";
                    }

                }
                if (handler != null) {
                    Message message = handler.obtainMessage();
                    message.obj = m;
                    handler.sendMessage(message);
                }
            }

            @Override
            public void onFailure(Call<List<Reservation>> call, Throwable t) {

            }
        });
    }

    public void outputManager(final ArrayList<DTO> arrayList, final Handler handler) {
        init();
        GitHub gitHub = retrofit.create(GitHub.class);
        Call<List<DTO>> call = gitHub.post_outPUT2("json");

        Log.v("Arr", "get1");
        call.enqueue(new Callback<List<DTO>>() {
            @Override
            public void onResponse(Call<List<DTO>> call, Response<List<DTO>> response) {
                List<DTO> user1 = response.body();
                Log.v("Arr", "get2");
                String m = null;
                for (DTO user : user1) {
                    Log.v("Arr", "get2");
                    arrayList.add(user);
                    m = "1";
                }
                if (handler != null) {
                    Message message = handler.obtainMessage();
                    message.obj = m;
                    handler.sendMessage(message);
                }
            }

            @Override
            public void onFailure(Call<List<DTO>> call, Throwable t) {

            }
        });
    }

    public void outputManager2(final ArrayList<DTO2> arr, final Handler handler) {
        init();
        GitHub gitHub = retrofit.create(GitHub.class);
        Call<List<DTO2>> call = gitHub.post_outPUT3("json");
        call.enqueue(new Callback<List<DTO2>>() {
            @Override
            public void onResponse(Call<List<DTO2>> call, Response<List<DTO2>> response) {
                List<DTO2> user1 = response.body();
                String m = null;
                for (DTO2 user : user1) {
                    arr.add(user);
                    m = "2";
                }
                if (handler != null) {
                    Message message = handler.obtainMessage();
                    message.obj = m;
                    handler.sendMessage(message);
                }
            }

            @Override
            public void onFailure(Call<List<DTO2>> call, Throwable t) {

            }
        });
    }

    public void outputManager3(final ArrayList<DTO3> arr, final Handler handler) {
        init();
        GitHub gitHub = retrofit.create(GitHub.class);
        Call<List<DTO3>> call = gitHub.post_outPUT4("json");
        call.enqueue(new Callback<List<DTO3>>() {
            @Override
            public void onResponse(Call<List<DTO3>> call, Response<List<DTO3>> response) {
                List<DTO3> user1 = response.body();
                String m = null;
                for (DTO3 user : user1) {
                    arr.add(user);
                    m = "3";
                }
                if (handler != null) {
                    Message message = handler.obtainMessage();
                    message.obj = m;
                    handler.sendMessage(message);
                }
            }

            @Override
            public void onFailure(Call<List<DTO3>> call, Throwable t) {

            }
        });
    }



   /* public void start(String id, final EditText e_person, final EditText e_time, final TextView e_dp) {
        init();
        GitHub gitHub = retrofit.create(GitHub.class);
        Log.v("hh1d", "김영훈");
        Call<List<Start>> call = gitHub.post_start(id);
        Log.v("hh1d", "김영훈");
        call.enqueue(new Callback<List<Start>>() {
            @Override
            public void onResponse(Call<List<Start>> call, Response<List<Start>> response) {
                Log.v("hh1d", "!김영훈@");
                List<Start> start = response.body();
                for(Start start1 : start) {
                    e_person.setText(""+start1.num_data);
                    e_time.setText(start1.time_data);
                    e_dp.setText(start1.dp_data);
                }
            }

            @Override
            public void onFailure(Call<List<Start>> call, Throwable t) {

            }
        });
        Timer timer = new Timer();
        timer.schedule(timerTask,2000);
        timer.cancel();
    }*/

    TimerTask timerTask = new TimerTask() {
        @Override
        public void run() {

        }
    };

  /*  public void basic(final String name, final Handler checkHandler) {
        init();
        GitHub gitHub = retrofit.create(GitHub.class);
        Log.v("hh1d", "김영훈");
        Call<List<DTO3>> call = gitHub.basic("json");
        Log.v("hh1d", "김영훈");
        call.enqueue(new Callback<List<DTO3>>() {
            @Override
            public void onResponse(Call<List<DTO3>> call, Response<List<DTO3>> response) {
                Log.v("hh1d", "!김영훈@");
                List<DTO3> start = response.body();
                String result = null;
                for(DTO3 start1 : start) {
                    Log.v("hh1d", "!김영훈@");
                    if(name.equals(start1.getBasic_name())){
                        result = "1";
                    }
                }
                if (checkHandler != null) {
                    Message messgae = checkHandler.obtainMessage();
                    messgae.obj = result;
                    checkHandler.sendMessage(messgae);
                }

            }

            @Override
            public void onFailure(Call<List<DTO3>> call, Throwable t) {

            }
        });
    }*/



    public void delect(int kim) {
        String b = null;
        Log.v("테스트트트트","ddd");
        if (kim == 1) {
            Log.v("테스트합시다","hhhh");
            b = "dents";
        } else if (kim == 2) {
            b = "waves";
        } else if (kim == 3) {
            b = "basics";
        }
        init();
        GitHub gitHub = retrofit.create(GitHub.class);
        Call<ResponseBody> call = gitHub.post_delete(b);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    Log.v("hhd", "dddh");
                }
            }
            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {

            }
        });
    }

    public void start(String id, final EditText e_person, final EditText e_time, final TextView e_dp) {
        init();
        GitHub gitHub = retrofit.create(GitHub.class);
        Log.v("hh1d", "ddhh");
        Call<List<Start>> call = gitHub.post_start(id);
        Log.v("hh1d", "ddhh");
        call.enqueue(new Callback<List<Start>>() {
            @Override
            public void onResponse(Call<List<Start>> call, Response<List<Start>> response) {
                Log.v("hh1d", "!ddhh");
                List<Start> start = response.body();
                for (Start start1 : start) {
                    e_person.setText("" + start1.num_data);
                    e_time.setText(start1.time_data);
                    e_dp.setText(start1.dp_data);
                }
            }

            @Override
            public void onFailure(Call<List<Start>> call, Throwable t) {

            }
        });

    }


    public void basic(final String name, final Handler checkHandler) {
        init();
        GitHub gitHub = retrofit.create(GitHub.class);
        Log.v("hh1d", "ddhh");
        Call<List<DTO3>> call = gitHub.basic("json");
        Log.v("hh1d", "ddhh");
        call.enqueue(new Callback<List<DTO3>>() {
            @Override
            public void onResponse(Call<List<DTO3>> call, Response<List<DTO3>> response) {
                List<DTO3> start = response.body();
                String result = "0";
                int sum = 0;
                for (DTO3 start1 : start) {
                    Log.v("확인중입니다", "이름 : " + start1.getBasic_name());
                    if (name.equals(start1.getBasic_name())) {
                        result = "0";
                    }
                }
                sum = start.size();
                if(sum != 0) {
                    result = "" + sum;
                }
                if (checkHandler != null) {
                    Message messgae = checkHandler.obtainMessage();
                    messgae.obj = result;
                    checkHandler.sendMessage(messgae);
                }
            }

            @Override
            public void onFailure(Call<List<DTO3>> call, Throwable t) {

            }
        });
    }

    public void dent(final String name, final Handler checkHandler) {
        init();
        GitHub gitHub = retrofit.create(GitHub.class);
        Log.v("hh1d", "ddhh");
        Call<List<DTO>> call = gitHub.dent("json");
        Log.v("hh1d", "ddhh");
        call.enqueue(new Callback<List<DTO>>() {
            @Override
            public void onResponse(Call<List<DTO>> call, Response<List<DTO>> response) {
                List<DTO> start = response.body();
                String result = "0";
                for (DTO start1 : start) {
                    if (name.equals(start1.getDent_name())) {
                        result = "2";
                    }
                }
                int sum = start.size();
                if(sum != 0) {
                    result = "" + sum;
                }
                if (checkHandler != null) {
                    Message messgae = checkHandler.obtainMessage();
                    messgae.obj = result;
                    checkHandler.sendMessage(messgae);
                }
            }

            @Override
            public void onFailure(Call<List<DTO>> call, Throwable t) {

            }
        });
    }


    public void wave(final String name, final Handler checkHandler) {
        init();
        GitHub gitHub = retrofit.create(GitHub.class);
        Log.v("hh1d", "ddhh");
        Call<List<DTO2>> call = gitHub.wave("json");
        Log.v("hh1d", "ddhh");
        call.enqueue(new Callback<List<DTO2>>() {
            @Override
            public void onResponse(Call<List<DTO2>> call, Response<List<DTO2>> response) {
                Log.v("hh1d", "ddhh@");
                List<DTO2> start = response.body();
                String result = "0";
                for (DTO2 start1 : start) {
                    Log.v("hh1d", "start" + start1.getWave_name());
                    if (name.equals(start1.getWave_name())) {
                        Log.v("hhd1", "check");
                        result = "2";
                    }
                }
                int sum = start.size();
                if(sum != 0) {
                    result = "" + sum;
                }
                if (checkHandler != null) {
                    Message messgae = checkHandler.obtainMessage();
                    messgae.obj = result;
                    checkHandler.sendMessage(messgae);
                }
            }

            @Override
            public void onFailure(Call<List<DTO2>> call, Throwable t) {

            }
        });
    }


    public void start(String id, final Handler checkHandler) {
        init();
        GitHub gitHub = retrofit.create(GitHub.class);
        Log.v("hh1d", "ddhh");
        Call<List<Start>> call = gitHub.post_start(id);
        Log.v("hh1d", "dddh");
        call.enqueue(new Callback<List<Start>>() {
            @Override
            public void onResponse(Call<List<Start>> call, Response<List<Start>> response) {
                Log.v("hh1d", "!ddd@");
                ArrayList arrayList = new ArrayList();
                List<Start> start = response.body();
                for (Start start1 : start) {
                    arrayList.add("" + start1.num_data);
                    arrayList.add(start1.time_data);
                    arrayList.add(start1.dp_data);
                }
                if (checkHandler != null) {
                    Message messgae = checkHandler.obtainMessage();
                    messgae.obj = arrayList;
                    checkHandler.sendMessage(messgae);
                }
            }

            @Override
            public void onFailure(Call<List<Start>> call, Throwable t) {

            }
        });
    }

    public void check(String s, final Handler checkHandler3) {
        init();
        String b = "";
        if (s.equals("치과")) {
            Log.v("테스트합시다","이이이");
            b = "dents";
        } else if (s.equals("초음파실")) {
            b = "waves";
        } else if (s.equals("기초검사실")) {
            b = "basics";
        }
        GitHub gitHub = retrofit.create(GitHub.class);
        Log.v("hh1d", "ddhh");
        Call<List<time>> call = gitHub.post_check(b);
        Log.v("hh1d", "ddhh");
        call.enqueue(new Callback<List<time>>() {
            @Override
            public void onResponse(Call<List<time>> call, Response<List<time>> response) {
                Log.v("hh1d", "!ddhh@");
                ArrayList arrayList = new ArrayList();
                List<time> start = response.body();
                for (time start1 : start) {
                    arrayList.add("" + start1.getNum());
                    arrayList.add(start1.getWait_time());
                }
                if (checkHandler3 != null) {
                    Message messgae = checkHandler3.obtainMessage();
                    messgae.obj = arrayList;
                    checkHandler3.sendMessage(messgae);
                }
            }

            @Override
            public void onFailure(Call<List<time>> call, Throwable t) {

            }
        });
    }
}
