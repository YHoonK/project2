package com.example.eg00.teamproject;

public class DTO3 {
    private String basic_id;
    private String basic_age;
    private String basic_name;

    public String getBasic_name() {
        return basic_name;
    }

    public void setBasic_name(String basic_name) {
        this.basic_name = basic_name;
    }

    public String getBasic_id() {
        return basic_id;
    }

    public void setBasic_id(String basic_id) {
        this.basic_id = basic_id;
    }

    public String getBasic_age() {
        return basic_age;
    }

    public void setBasic_age(String basic_age) {
        this.basic_age = basic_age;
    }

    public DTO3(String basic_id,String basic_name, String basic_age) {

        this.basic_id = basic_id;
        this.basic_name = basic_name;
        this.basic_age = basic_age;
    }
}
