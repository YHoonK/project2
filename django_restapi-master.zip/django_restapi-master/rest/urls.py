"""rest URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf.urls import url, include
from rest_framework import routers
from rest_framework_swagger.views import get_swagger_view
from department.api import *

import department.api

router = routers.DefaultRouter()
router.register('userset', department.api.UsersetViewSet)
router.register('apply', department.api.ApplysViewSet)
router.register('basic_dp', department.api.BasicViewSet)
router.register('dent_dp', department.api.DentViewSet)
router.register('wave_dp', department.api.WaveViewSet)

urlpatterns = [
    path('admin/', admin.site.urls),
    url(r'^api/swagger', get_swagger_view(title='Rest API Document')), # 관리자
    url(r'^api/team/', include((router.urls, 'userset'), namespace='api')), # 회원 데이터
    url(r'^api/team/', include((router.urls, 'apply'), namespace='api')), # 회원예약 데이터
    url(r'^api/team/', include((router.urls, 'basic_dp'), namespace='api')), # 기초검사실 데이터
    url(r'^api/team/', include((router.urls, 'dent_dp'), namespace='api')), # 치과검사실 데이터
    url(r'^api/team/', include((router.urls, 'wave_dp'), namespace='api')), # 초음파실 데이터
    path('api/setdata/<apply_name>', setdata, name='setdata'), #대기시간 가장 짧은과 추천,그 과의 대기시간,대기인원 표시,그과에 자신의 대기순위넣기
    path('api/dpdata/<dp_name>', dpdata, name='dpdata'),# 대기진료 부서별 대기자 삭제
    path('api/nowdata/<now_data>', nowdata, name='nowdata'),# 대기진료 부서별 대기시간, 대기인원 표시
]