#-*-coding:utf-8

from django.http import HttpResponse

from .models import basics, blood, dents, waves, xray, checkup, Applys, Userset
import pandas as pd
import numpy as np
import json, datetime
from rest_framework import serializers, viewsets
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression

# 기초검사실 view
class BasicSerializer(serializers.ModelSerializer):
    class Meta:
        model = basics
        fields = '__all__'
class BasicViewSet(viewsets.ModelViewSet):
    queryset = basics.objects.all()
    serializer_class = BasicSerializer

# 치과검사실 view
class DentSerializer(serializers.ModelSerializer):
    class Meta:
        model = dents
        fields = '__all__'
class DentViewSet(viewsets.ModelViewSet):
    queryset = dents.objects.all()
    serializer_class = DentSerializer

# 초음파실 view
class WaveSerializer(serializers.ModelSerializer):
    class Meta:
        model = waves
        fields = '__all__'
class WaveViewSet(viewsets.ModelViewSet):
    queryset = waves.objects.all()
    serializer_class = WaveSerializer

# 예약자정보 view
class ApplysSerializer(serializers.ModelSerializer):
    class Meta:
        model = Applys
        fields = '__all__'
class ApplysViewSet(viewsets.ModelViewSet):
    queryset = Applys.objects.all()
    serializer_class = ApplysSerializer

# 회원정보 view
class UsersetSerializer(serializers.ModelSerializer):
    class Meta:
        model = Userset
        fields = '__all__'
class UsersetViewSet(viewsets.ModelViewSet):
    queryset = Userset.objects.all()
    serializer_class = UsersetSerializer

# 대기진료 부서 알고리즘
def setdata(request, apply_name):

    print("데이터 진입 : ", apply_name)

    df = pd.read_csv('department/basic_data.csv', index_col=0)
    X = df.loc[:, '나이']
    y = df.loc[:, '진료소요시간']
    X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=5, test_size=0.3)
    linr_basic = LinearRegression()
    linr_basic.fit(X_train.values.reshape(-1, 1), y_train)
    #print("Score : %.3f" % linr_basic.score(X_test.values.reshape(-1, 1), y_test))

    # 치과
    df = pd.read_csv('department/dent_data.csv', index_col=0)
    X = df[['나이', '1년내 치과검진 유무']]
    y = df[['진료소요시간']]
    X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=5, test_size=0.3)
    linr_dent = LinearRegression()
    linr_dent.fit(X_train, y_train)
    #print("Score : %.3f" % linr_dent.score(X_test, y_test))

    # 초음파실
    df = pd.read_csv('department/wave_data.csv', index_col=0)
    X = df[['나이', '음주유무']]
    y = df.loc[:, '진료소요시간']
    X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=5, test_size=0.3)
    linr_wave = LinearRegression()
    linr_wave.fit(X_train, y_train)
    #print("Score : %.3f" % linr_wave.score(X_test, y_test))

    for data in Applys.objects.filter(apply_name=apply_name):
        dataset = data.apply_name
        print("URL에서 받은 값 : ", apply_name)
        print("받은값을 DB에서 찾아진 값 : ", dataset)

    id = dataset # 아이디 값
    row = Applys.objects.get(apply_name=id)
    age = row.apply_age # 나이 값
    name = row.apply_center #이름
    moojin_dent = row.apply_dent  # 구강 문진표 값
    moojin_wave = row.apply_drinking  # 음주 문진표 값

    # insert = checkup(depart='basic')
    # insert.save()
    # insert = checkup(depart='dent')
    # insert.save()
    # insert = checkup(depart='wave')
    # insert.save()

    # if bool(dents.objects.filter(dent_id=id)):
    #     bye = dents.objects.get(dent_id=id)
    #     bye.delete()
    # if bool(basic.objects.filter(basic_id=id)):
    #     bye = basic.objects.get(basic_id=id)
    #     bye.delete()
    # if bool(waves.objects.filter(wave_id=id)):
    #     bye = waves.objects.get(wave_id=id)
    #     bye.delete()

    wait_time = []
    test_data = []

    if row.apply_basic_count=='1':

           # 기초검사실 대기시간
           print('들어옴')
           for num1 in basics.objects.all():
                test_data.append(num1.basic_age)
           age_data1 = np.array(test_data)

           de_basic = linr_basic.predict(age_data1.reshape(-1, 1)).sum()
           wait_time.append(de_basic)
           print('기초검사실대기시간:', wait_time[0])

    if row.apply_basic_count=='0':
           wait_time.append(10000000)

    test_data = []
    if row.apply_dent_count=='1':
           # 치과 대기시간
           for num1 in dents.objects.all():
                test_data.append([num1.dent_age, num1.dent_year])
           age_data3 = np.array(test_data)

           de_dent = linr_dent.predict(age_data3).sum()
           wait_time.append(de_dent)
           print('치과대기시간:', wait_time[1])
    if row.apply_dent_count=='0':
           wait_time.append(10000000)

    test_data = []
    if row.apply_wave_count=='1':
           # 초음파실 대기시간
           for num1 in waves.objects.all():
                test_data.append([num1.wave_age, num1.wave_alcohol])
           age_data4 = np.array(test_data)

           de_wave = linr_wave.predict(age_data4).sum()
           wait_time.append(de_wave)
           print('초음파실대기시간:', wait_time[2])

    if row.apply_wave_count=='0':
           wait_time.append(10000000)

    min_time = min(wait_time)
    basic_dp = "기초검사실"
    dent_dp = "치과"
    wave_dp = "초음파실"

    if wait_time.index(min_time) == 0:
            num = basics.objects.count()
            print('대기인원 :', num)
            print("대기시간 :", min_time)
            print('추천과 :',basic_dp)

            num_data = num
            time_data = datetime.timedelta(seconds=min_time)
            dp_data = basic_dp

            row.apply_basic_count = '0'
            row.save()
            insert = basics(basic_name=name, basic_id=id, basic_age=age)
            insert.save()
    elif wait_time.index(min_time) == 1:
            num = dents.objects.count()
            print('대기인원 :', num)
            print("대기시간 :", min_time)
            print('추천과 :', dent_dp)

            num_data = num
            time_data = datetime.timedelta(seconds=min_time)
            dp_data = dent_dp

            row.apply_dent_count = '0'
            row.save()
            insert = dents(dent_name=name, dent_id=id, dent_age=age, dent_year=moojin_dent)
            insert.save()

    elif wait_time.index(min_time) == 2:
            num = waves.objects.count()
            print('대기인원 :', num)
            print("대기시간 :", min_time)
            print('추천과 :', wave_dp)

            num_data = num
            time_data = datetime.timedelta(seconds=min_time)
            dp_data = wave_dp

            row.apply_wave_count = '0'
            row.save()
            insert = waves(wave_name=name, wave_id=id, wave_age=age, wave_alcohol=moojin_wave)
            insert.save()

    mytime = datetime.datetime.min + time_data  # datetime.datetime은 년/월/일까지 계산하게 돼서 24시가 넘는 h는 일(day)로 변환됩니다.
    h, m, s = mytime.hour, mytime.minute, mytime.second
    timeset = repr(h) + "시" + repr(m) + "분" + repr(s) + "초"

    json_data = [{"num_data": num_data, "time_data": timeset, "dp_data": dp_data}]
    print("최종분석 값 출력 : ", json_data)

    return HttpResponse(json.dumps(json_data, ensure_ascii=False, indent="\t"))


# 대기진료 부서별 대기자 삭제 알고리즘
def dpdata(request, dp_name):

    if(dp_name=='basics'):
        del_row = basics.objects.order_by('id').first()
        del_row.delete()
    elif(dp_name=='dents'):
        del_row = dents.objects.order_by('id').first()
        del_row.delete()
    elif(dp_name=='waves'):
        del_row = waves.objects.order_by('id').first()
        del_row.delete()
    return HttpResponse(dp_name, "테이블에서 1개의 row가 삭제됨")

def nowdata(request, now_data):

    df = pd.read_csv('department/basic_data.csv', index_col=0)
    X = df.loc[:, '나이']
    y = df.loc[:, '진료소요시간']
    X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=5, test_size=0.3)
    linr_basic = LinearRegression()
    linr_basic.fit(X_train.values.reshape(-1, 1), y_train)
    #print("Score : %.3f" % linr_basic.score(X_test.values.reshape(-1, 1), y_test))

    # 치과
    df = pd.read_csv('department/dent_data.csv', index_col=0)
    X = df[['나이', '1년내 치과검진 유무']]
    y = df[['진료소요시간']]
    X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=5, test_size=0.3)
    linr_dent = LinearRegression()
    linr_dent.fit(X_train, y_train)
    #print("Score : %.3f" % linr_dent.score(X_test, y_test))

    # 초음파실
    df = pd.read_csv('department/wave_data.csv', index_col=0)
    X = df[['나이', '음주유무']]
    y = df.loc[:, '진료소요시간']
    X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=5, test_size=0.3)
    linr_wave = LinearRegression()
    linr_wave.fit(X_train, y_train)

    dp = now_data
    print("내가 입력한 부서는?", dp)
    num = 0 #현재대기인원
    print("카운팅", num)
    wait_time=0
    if dp=='basics':
        num = basics.objects.count()
        test_data=[]
        for num1 in basics.objects.all():
          test_data.append(num1.basic_age)
        age_data1 = np.array(test_data)
        de_basic = linr_basic.predict(age_data1.reshape(-1, 1)).sum()
        wait_time=de_basic
    if dp=='dents':
        num = dents.objects.count()
        test_data = []
        for num1 in dents.objects.all():
            test_data.append([num1.dent_age, num1.dent_year])
        age_data3 = np.array(test_data)
        de_dent = linr_dent.predict(age_data3).sum()
        wait_time=de_dent
    if dp=='waves':
        num = waves.objects.count()
        test_data=[]
        for num1 in waves.objects.all():
            test_data.append([num1.wave_age, num1.wave_alcohol])
        age_data4 = np.array(test_data)
        de_wave = linr_wave.predict(age_data4).sum()
        wait_time=de_wave

    time_data2 = datetime.timedelta(seconds=wait_time)

    mytime = datetime.datetime.min + time_data2  # datetime.datetime은 년/월/일까지 계산하게 돼서 24시가 넘는 h는 일(day)로 변환됩니다.
    h, m, s = mytime.hour, mytime.minute, mytime.second
    timeset = repr(h) + "시" + repr(m) + "분" + repr(s) + "초"

    son_data = [{"num":num, "wait_time":timeset}]
    print("최종분석 값 출력 : ", son_data)

    return HttpResponse(json.dumps(son_data, ensure_ascii=False, indent="\t"))