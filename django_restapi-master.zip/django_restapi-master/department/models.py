from django.db import models

# 치과테이블
class dents(models.Model):
    dent_name = models.TextField()
    dent_id = models.TextField()
    dent_age = models.IntegerField(default=0)
    dent_year = models.IntegerField(default=0)

# 초음파실테이블
class waves(models.Model):
    wave_name = models.TextField()
    wave_id = models.TextField()
    wave_age = models.IntegerField(default=0)
    wave_alcohol = models.IntegerField(default=0)

# 기초검사실테이블
class basics(models.Model):
    basic_name = models.TextField()
    basic_id = models.TextField()
    basic_age = models.IntegerField(default=0)

# 예약정보테이블_안쓰는거
class Apply(models.Model):
    apply_name = models.TextField()
    apply_age = models.TextField()
    apply_sex = models.TextField()
    apply_division = models.TextField()
    apply_center = models.TextField()
    apply_pawntel = models.TextField()
    apply_consulting = models.TextField()
    apply_dent = models.TextField()
    apply_drinking = models.TextField()

# 예약정보테이블_새로운거
class Applys(models.Model):
    apply_name = models.TextField()
    apply_age = models.TextField()
    apply_sex = models.TextField()
    apply_division = models.TextField()
    apply_center = models.TextField()
    apply_pawntel = models.TextField()
    apply_consulting = models.TextField()
    apply_dent = models.TextField()
    apply_drinking = models.TextField()
    apply_basic_count = models.TextField(default=1)
    apply_dent_count = models.TextField(default=1)
    apply_wave_count = models.TextField(default=1)

# 회원정보테이블
class Userset(models.Model):
    user_id = models.TextField()
    user_pwd = models.TextField()
    user_name = models.TextField()
    user_age = models.TextField()
    user_sex = models.TextField()
    user_tel = models.TextField()
    user_pawntel = models.TextField()
    user_email = models.TextField()
    user_date = models.TextField()
    user_usernum = models.TextField()
    user_add = models.TextField()

class blood(models.Model):
    blood_id = models.TextField()
    blood_age = models.IntegerField(default=0)

class xray(models.Model):
    xray_id = models.TextField()
    xray_age = models.IntegerField(default=0)

class checkup(models.Model):
    depart = models.TextField()

class dent(models.Model):
    dent_id = models.TextField()
    dent_age = models.IntegerField(default=0)
    dent_year = models.IntegerField(default=0)

class wave(models.Model):
    wave_id = models.TextField()
    wave_age = models.IntegerField(default=0)
    wave_alcohol = models.IntegerField(default=0)

class basic(models.Model):
    basic_id = models.TextField()
    basic_age = models.IntegerField(default=0)